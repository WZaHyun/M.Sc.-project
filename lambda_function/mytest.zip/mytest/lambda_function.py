import json
import csv
import boto3
import requests

from boto3.dynamodb.conditions import Key, Attr




_TableName_ = "ModuleInfo"
# define parameters
moduleID = 'M-id'
moduleName = 'M-name'
moduleType = 'M-type'
Primary_Key = '1'
client = boto3.client('dynamodb')
DB = boto3.resource('dynamodb')
table = DB.Table(_TableName_)



def sets3(modulename):
    data = []
    s3 = boto3.resource('s3')

    bucket = s3.Bucket('qzbucket-test')
    obj = bucket.Object('{}.csv'.format(modulename))
    response = obj.get()
    lines = response['Body'].read().decode('utf-8').splitlines()

    for row in csv.DictReader(lines):
        data.append(row)
        # here you get a sequence of dicts
        # do whatever you want with each line here
    return (data)  # data[0]['definition'] gets the first item's definition /data[0]['terms']


def dispatch(intent_request):
    slots = intent_request['currentIntent']['slots']
    modulename = slots['modulename'].lower()

    first = slots['firstA']
    second = slots['secondA']
    third = slots['thirdA']
    fourth = slots['fourthA']
    fifth = slots['fifthA']
    sixth = slots['sixthA']
    seveth = slots['seventhA']
    eighth = slots['eighthA']
    ninth = slots['ninthA']
    
    
    

    # modulename='nlp'
    
    # first='no'
    # second='c'
    # third='c'
    # fourth='e'
    # fifth = 'c'
    # sixth = 'b'
    # seveth = 'b'
    # eighth = 'b'
    # ninth = 'b'
    # tenth = None

    if modulename and not first:
        if findModuleName(modulename):
            return {
                "dialogAction": {
                    "type": "ElicitSlot",
                    "message": {
                        "contentType": "PlainText",
                        "content": "Have you ever learnt about {}?".format(modulename)
                    },
                    "intentName": intent_request['currentIntent']['name'],
                    "slots": intent_request['currentIntent']['slots'],
                    "slotToElicit": "firstA",
                    "responseCard": {
                        "version": 1,
                        "contentType": "application/vnd.amazonaws.card.generic",
                        "genericAttachments": [
                            {
                                "title": "Have you ever learnt about {}?".format(modulename),
                                "subTitle": "Yes or No",
                                "buttons": [
                                    {
                                        "text": "Yes",
                                        "value": "yes"
                                    },
                                    {
                                        "text": "No",
                                        "value": "no"
                                    }
                                ]
                            }
                        ]
                    }
                }

            }

        else:
            return {
                "dialogAction": {
                    "type": "ElicitSlot",
                    "message": {
                        "contentType": "PlainText",
                        "content": "again"
                    },
                    "intentName": intent_request['currentIntent']['name'],
                    "slots": intent_request['currentIntent']['slots'],
                    "slotToElicit": "modulename",
                    "responseCard": {
                        "version": 1,
                        "contentType": "application/vnd.amazonaws.card.generic",
                        "genericAttachments": [
                            {
                                "title": "Which module do you want to choose?",
                                "subTitle": "Swipe left/right for more options.",
                                "buttons": [
                                    {
                                        "text": "Deep Learning",
                                        "value": "deep learning"
                                    },
                                    {
                                        "text": "Machine Learning",
                                        "value": "machine learning"
                                    },
                                    {
                                        "text": "Data Analysis",
                                        "value": "data analysis"
                                    }
                                ]
                            },
                             {
                                "title": "Which module do you want to choose?",
                                "subTitle": "Swipe left/right for more options.",
                                "buttons": [
                                    {
                                        "text": "NLP",
                                        "value": "nlp"
                                    }
                                ]
                            }
                            
                        ]
                    }
                }

            }
    
    if modulename and first and not second:
        return builttest(intent_request, modulename, 0)
    if modulename and second and not third:
        return builttest(intent_request, modulename, 1)
    if modulename and third and not fourth:
        return builttest(intent_request, modulename, 2)
    if modulename and fourth and not fifth:
        return builttest(intent_request, modulename, 3)
    if modulename and fifth and not sixth:
        return builttest(intent_request, modulename, 4)
    if modulename and sixth and not seveth:
        return builttest(intent_request, modulename, 5)
    if modulename and seveth and not eighth:
        return builttest(intent_request, modulename, 6)
    if modulename and eighth and not ninth:
        return builttest(intent_request, modulename, 7)
    txt=intent_request['inputTranscript']
    if txt==ninth:
        txt=None
    if modulename and ninth and not txt:
        return builttest(intent_request, modulename, 8)
    slots['tenthA']=txt
    tenth=slots['tenthA']
    if modulename and ninth and tenth:
        answers = [first, second, third, fourth, fifth, sixth, seveth, eighth, ninth, tenth]
        return getmarks(answers,modulename)
    
    
    
def findModuleName(modulename):  # in ... db?
    # if in db
    response = table.scan(FilterExpression=Attr(moduleName).eq(modulename))
    # print(response)
    if response['Count'] != 0:
        # print("111111")
        # return builttest(modulename)
        return True
    else:
        # content="Sorry,but this module does not exist."
        # return close(content)
        return False
    # else exp


# def similarity_text():


def builttest(intent_request, modulename, q):
    data_q = sets3(modulename)
    
    if q == 0:
        slot_to_elicit = 'secondA'
    elif q == 1:
        slot_to_elicit = 'thirdA'
    elif q == 2:
        slot_to_elicit = 'fourthA'
    elif q == 3:
        slot_to_elicit = 'fifthA'
    elif q == 4:
        slot_to_elicit = 'sixthA'
    elif q == 5:
        slot_to_elicit = 'seventhA'
    elif q == 6:
        slot_to_elicit = 'eighthA'
    elif q == 7:
        slot_to_elicit = 'ninthA'
    elif q == 8:
        slot_to_elicit = 'tenthA'

    return elicit_m(intent_request, str(data_q[q]['Question']), slot_to_elicit)  # q


def text_similarity(answer,data):
    url = "https://api.twinword.com/api/text/similarity/latest/"

    querystring = {"text1": answer,"text2": data[8]['Answer']}

    headers = {
    'x-rapidapi-host': "api.twinword.com",
    'x-rapidapi-key': "X-Twaip-Key: d/kIS6gjw5OAKV+C2Rj2Tpxa7LNB/SP6bkM4USZs2NblLIF1L53iq91bqRDtakMqM77ZIRi2HjS1YZt3qtOZgQ=="
    }

    response = requests.request("GET", url, headers=headers, params=querystring)
    text=json.loads(response.text)
    
    return round(text["similarity"],2)*10
   
   

# def distiqtype(moduletestrequest):#what type of the question?
def getmarks(answers,modulename):
    data=sets3(modulename)
    points = 0
    count=0
    ts=0
    if (str(answers[0]).lower() == 'yes'):
        points = points + 10
    # a=str(data[0]['Answer']).lower()
    # b=str(answers[1]).lower()
    for i in range(0, 9):
        if i<=7:
            a = str(data[i]['Answer']).lower()
            b = str(answers[i + 1]).lower()
            if str(a) == str(b):
              count=count+1
              points = points + 10
        elif i==8:
            ts=text_similarity(str(answers[i+1]),data)
            points=points+ts
    standard=int(data[0]['Standard'])
    if points<standard:
        return close("Graded:" + str(points)+'/100 points. '+'On the multiple choice, you got {} questions right, \
        and you got {} points on the last one. So I suggest you taking the foundation(primer) level of module.'.format(count,ts))
    else:
        return close("Graded:" + str(points)+'/100 points. '+'On the multiple choice, you got {} questions right, \
        and you got {} points on the last one. So I suggest you taking the advanced level of module.'.format(count,ts))



def elicit_m(intent_request, qcontent, slot_to_elicit):
    
    response = {
        "dialogAction": {
            "type": "ElicitSlot",
            "message": {
                "contentType": "PlainText",
                "content": qcontent
            },
            "intentName": intent_request['currentIntent']['name'],
            "slots": intent_request['currentIntent']['slots'],
            "slotToElicit": slot_to_elicit

        }

    }

    return response


def close(content):
    response = {
        #   'sessionAttributes': session_attributes,
        'dialogAction': {
            "type": 'Close',
            "fulfillmentState": 'Fulfilled',
            'message': {
                'content': content,
                'contentType': "PlainText"
            }
        }
    }
    return response


def lambda_handler(event, context):
    # response='2'
    response = dispatch(event)
    # response=text_similarity('i love you ','i like you')
    # TODO implement
    return response

