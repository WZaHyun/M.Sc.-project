import json
import boto3
import kms
import math, random 
import smtplib
from email.mime.text import MIMEText
from email.header import Header


from boto3.dynamodb.conditions import Key, Attr
_TableName_="UserInfo"
#define parameters
userID='EmailAddress'
userName='UserName'
veriF='verified'

client = boto3.client('dynamodb')
DB=boto3.resource('dynamodb')
table=DB.Table(_TableName_)
otp=''

def generateOTP() : 
  
    # Declare a digits variable   
    # which stores all digits  
    digits = "0123456789"
    OTP = "" 
   # length of password can be chaged 
   # by changing value in range 
    for i in range(4) : 
        OTP += digits[math.floor(random.random() * 10)] 
  
    return OTP 
  


def sentMail(useremail,message):
    from_addr = '2384102107@qq.com'
    password = 'tliksauaubcddhge'
    to_addr = useremail
 
    smtp_server = 'smtp.qq.com'
 
    msg = MIMEText(message,'plain','utf-8')
    msg['From'] = Header(from_addr)
    msg['To'] = Header(to_addr)
    msg['Subject'] = Header('Your OTP code')
    server=smtplib.SMTP_SSL(smtp_server)
    server.connect(smtp_server,465)
    server.login(from_addr, password)
    server.sendmail(from_addr, to_addr, msg.as_string())
    server.quit()  

def findUser(finduserrequest):
     #if in db  
    response = table.scan(FilterExpression=Attr(userID).eq(finduserrequest[0]) & Attr(veriF).eq('yes'))
    if response['Count'] != 0:
        
        return True
    else:
        return False
 
    
def createUser(newrequest):
    
    # table.put_item(
    #   Item={
    #         'EmailAddress': newrequest[0],
    #         'UserName': newrequest[1]
           
    #     }
    # )
    if kms.kmsen(newrequest):
        return close("Create an account succeeded and still need to be verified.")
    else:
        return close("Unknow error occured, please try it again.")
def vUser(newrequest):
    
    table.update_item(
      Key={
            'EmailAddress': newrequest[0]
        },
        UpdateExpression = "set verified =:updated",
        ExpressionAttributeValues = {':updated':'yes'},
        ReturnValues="UPDATED_NEW"
    )
    return close("SIGN UP SUCCEEDED.")

def close(content):
  response={
    #   'sessionAttributes': session_attributes,
      'dialogAction': {
        "type": 'Close',
        "fulfillmentState": 'Fulfilled',
        'message': {
          'content': content,
          'contentType': "PlainText"
    }
  }
}
  
  return response
  
def dispatch(intent_request):
    
    slots = intent_request['currentIntent']['slots']
    isnewuser=slots['greetingsIntent']
    username=slots['username']
    useremail=slots['useremail']
    db_password=slots['password']
    # db_password='7789'
    # username='tina'
    # useremail='makixian@outlook.com'
    if isnewuser and not username and not useremail and not db_password:
        if isnewuser=='yes':
             return close("Hi! Nice to see you. I am your online assistant. Here are a few examples of what you could say: 'I want to book an online course.' 'Cancel my order.' 'My order list'. Other services are also provided, here are some examples 'Get definition', 'take a placement test.'")
    
             
        else:
             return {
                "dialogAction": {
                    "type": "ElicitSlot",
                    "intentName": intent_request['currentIntent']['name'],
                    "slots": intent_request['currentIntent']['slots'],
                    "slotToElicit": "username"
                }
                }
    
    if isnewuser and username and not useremail and not db_password:
        if isnewuser=='yes':
             return close("Hi! Nice to see you. I am your online assistant. Here are a few examples of what you could say: 'I want to book an online course.' 'Cancel my order.' 'My order list'. Other services are also provided, here are some examples 'Get definition', 'Provide me a placement test.'")
    
        else:
             return {
                "dialogAction": {
                    "type": "ElicitSlot",
                    "intentName": intent_request['currentIntent']['name'],
                    "slots": intent_request['currentIntent']['slots'],
                    "slotToElicit": "useremail"
                }
                }
             
    
    if username and useremail and not db_password:
         otp=str(generateOTP())
         message="OTP CODE: "+otp
         finduserrequest=[useremail,username,otp]
         if findUser(finduserrequest):
             return close('Hi {},but this email address has already been registered.'.format(finduserrequest[1]))
        #  else:
        #      return createUser(finduserrequest)
         else:
            
             sentMail(useremail,message)
             createUser(finduserrequest)
             return {
                "dialogAction": {
                    "type": "ElicitSlot",
                    "intentName": intent_request['currentIntent']['name'],
                    "slots": intent_request['currentIntent']['slots'],
                    "slotToElicit": "password"
                }
                }
    if username and useremail and db_password:
         finduserrequest=[useremail,username,db_password]
         otp=kms.kmsde(finduserrequest)
         if db_password==otp:
             return vUser(finduserrequest)
         else:
             return close('OTP Error.')
      
       
  
    
     
    
def lambda_handler(event, context):
    response=dispatch(event)
    # finduserrequest=['0307zixian@gmail.com','Tina']
    # if findUser(finduserrequest):
    #     return ".."
    return response
    
   
   