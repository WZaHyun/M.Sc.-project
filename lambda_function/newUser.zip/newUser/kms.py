import base64
import json
import boto3
import string

def encrypt_password_to_b64(key_id=None, password=None):
    """
    Function to encrypt the password with KMS
    :param: key_id: KMS Key Id
    :param: password to encrypt
    :return: String password in base64
    """
    client = boto3.client('kms')
    encrypted = client.encrypt(
        KeyId=key_id,
        Plaintext=password
    )
    encrypted_b64 = base64.b64encode(encrypted['CiphertextBlob'])
   
    return encrypted_b64.decode("utf-8") 


def put_password_in_dynamodb(useremail,password,username):
    """
    Function to store the b64 password in DynamoDB
	:param env: String for the environment name (usually dev / prod etc.)
	:param stack_name: Name of the cloudformation stack
	:param password: string of the base64 encrypted password
    """
    client = boto3.resource('dynamodb')
    table = client.Table('UserInfo')
    response = table.put_item(
        Item={
            'EmailAddress': useremail,
            'passwordbase64': password,
            'UserName':username
        }
    )

def get_password_from_dynamodb(useremail):
   
    client = boto3.resource('dynamodb')
    table = client.Table('UserInfo')
    response = table.get_item(
        Key={
            'EmailAddress': useremail
        }
    )
    if 'Item' in response:
        if 'passwordbase64' in response['Item']:
            
            return response['Item']['passwordbase64']
        else:
            return False 
    else:
        return False
        
def decrypt_password_from_b64(password_b64):
    """
    Function to encrypt the password with KMS
    :param password_b64: b64 string of the encrypted password
    """
    password_encrypted = base64.b64decode(password_b64)
    client = boto3.client('kms')
    password = client.decrypt(CiphertextBlob=password_encrypted)
    return password['Plaintext']


def kmsen(newrequest):
    useremail=newrequest[0]
    username=newrequest[1]
    db_password=newrequest[2]
    
    # There is nothing to do for a delete request
    # useremail='abc123@outlook.com'
    # db_password='123'
    kmsid='your password'
    encrypted_password = encrypt_password_to_b64(kmsid, db_password)
    put_password_in_dynamodb(useremail,encrypted_password,username)
    return True
    
def kmsde(newrequest):
    useremail=newrequest[0]
    password_b64 = get_password_from_dynamodb(useremail)
    if password_b64 != False:
        password = decrypt_password_from_b64(password_b64)
        return  password.decode("utf-8")
    else:
        return False
