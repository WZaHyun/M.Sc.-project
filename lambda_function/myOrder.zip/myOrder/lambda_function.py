import json
import boto3
import smtplib
import kms
import math, random
from email.mime.text import MIMEText
from email.header import Header
from boto3.dynamodb.conditions import Key, Attr
_TableName_="UserOrder"
#define parameters
userEmail='EmailAddress'
orderState='OrderState'
client = boto3.client('dynamodb')
DB=boto3.resource('dynamodb')
table=DB.Table(_TableName_)

_TableName2_="ModuleInfo"
#define parameters
moduleID='M-id'
moduleName='M-name'
moduleType='M-type'

client2 = boto3.client('dynamodb')
DB2=boto3.resource('dynamodb')
table2=DB2.Table(_TableName2_)


_TableName3_="UserInfo"
#define parameters
userID='EmailAddress'
veriF='verified'
client3 = boto3.client('dynamodb')
DB3=boto3.resource('dynamodb')
table3=DB3.Table(_TableName3_)

otp=''

orderstatus=[]


def generateOTP() : 
  
    # Declare a digits variable   
    # which stores all digits  
    digits = "0123456789"
    OTP = "" 
   # length of password can be chaged 
   # by changing value in range 
    for i in range(4) : 
        OTP += digits[math.floor(random.random() * 10)] 
  
    return OTP 
def vUser(newrequest):
    
    table3.update_item(
      Key={
            'EmailAddress': newrequest[0]
        },
        UpdateExpression = "set passwordbase64 =:updated",
        ExpressionAttributeValues = {':updated':''},
        ReturnValues="UPDATED_NEW"
    )

def sentMailotp(useremail,message):
    from_addr = '2384102107@qq.com'
    password = 'tliksauaubcddhge'
    to_addr = useremail
 
    smtp_server = 'smtp.qq.com'
 
    msg = MIMEText(message,'plain','utf-8')
    msg['From'] = Header(from_addr)
    msg['To'] = Header(to_addr)
    msg['Subject'] = Header('Your OTP code')
    server=smtplib.SMTP_SSL(smtp_server)
    server.connect(smtp_server,465)
    server.login(from_addr, password)
    server.sendmail(from_addr, to_addr, msg.as_string())
    server.quit()  
def verifiedUser(finduserrequest):
     #if in db  
    isExist = table3.scan(FilterExpression=Attr(userID).eq(finduserrequest[0]) & Attr(veriF).eq('yes'))
    if isExist['Count']!=0: #exist
        return True
       
    elif isExist['Count']==0: #not exist
        return False
    #else exp

def dispatch(intent_request):
    slots = intent_request['currentIntent']['slots']
    useremail=slots['useremail']
    db_password=slots['password']
    # useremail='makixian@outlook.com'
    # db_password=None
    
    if useremail and not db_password:
        otp=str(generateOTP())
        message="OTP CODE: "+otp
        finduserrequest=[useremail,otp]
        if verifiedUser(finduserrequest)==True:
             sentMailotp(useremail,message)
             if kms.kmsen(finduserrequest):
                return {
                "dialogAction": {
                    "type": "ElicitSlot",
                    "message": {
                        "contentType": "PlainText",
                        "content": "Please enter the verification code. An OTP code already has sent to your email address."
                    },
                    "intentName": intent_request['currentIntent']['name'],
                    "slots": intent_request['currentIntent']['slots'],
                    "slotToElicit": "password"
                    
                }
                }
             else:
                return close("Unknown Error, please try it again.")
        elif verifiedUser(finduserrequest)==False:
             return close('Hi,but this email address has not been registered. You should sign up first.')
    
    if useremail and db_password:
         finduserrequest=[useremail,db_password]
         if verifiedUser(finduserrequest)==True:
             otp=kms.kmsde(finduserrequest)
             if db_password==otp:
                 orderid=findEmailAddress(useremail)
                 if orderid== False:
                    return close("This account does not have any order information.")
                 else:
                    ordermessage=findModule(orderid)
                    return close(ordermessage)
                
             else:
                return close('OTP Error.')
      
         elif verifiedUser(finduserrequest)==False:
             return close('Hi,but this email address has not been registered. You should sign up first.')
    

def findEmailAddress(useremail):
    orderlist = table.scan(FilterExpression=Attr(userEmail).eq(useremail))
    if orderlist['Count']==0:
      return False
    else:
      orderid=[]
      for i in range(0,orderlist['Count']):
        orderid.append(orderlist['Items'][i][moduleID])
        orderstatus.append(orderlist['Items'][i][orderState])
      return orderid
    
def findModule(orderid):
    ordermessage=""
    for i in range (0,len(orderid)):
      orderlist = table2.scan(FilterExpression=Attr(moduleID).eq(orderid[i]))
      ordermessage=ordermessage+"{}. {}({}/{})\n".format(i+1,orderlist['Items'][0][moduleName],orderlist['Items'][0][moduleType],orderstatus[i])
    
    return ordermessage
    
    

def close(content):
  response={
    #   'sessionAttributes': session_attributes,
      'dialogAction': {
        "type": 'Close',
        "fulfillmentState": 'Fulfilled',
        'message': {
          'content': content,
          'contentType': "PlainText"
    }
  }
}
  
  return response
  

def lambda_handler(event, context):
    response=dispatch(event)
    return response