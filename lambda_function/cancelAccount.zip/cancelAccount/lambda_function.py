import json
import boto3
import smtplib
import kms
import math, random
from email.mime.text import MIMEText
from email.header import Header
from boto3.dynamodb.conditions import Key, Attr

_TableName2_="UserInfo"
#define parameters
userID='EmailAddress'
veriF='verified'

client2 = boto3.client('dynamodb')
DB2=boto3.resource('dynamodb')
table2=DB2.Table(_TableName2_)

otp=''

def generateOTP() : 
  
    # Declare a digits variable   
    # which stores all digits  
    digits = "0123456789"
    OTP = "" 
   # length of password can be chaged 
   # by changing value in range 
    for i in range(4) : 
        OTP += digits[math.floor(random.random() * 10)] 
  
    return OTP 
def vUser(newrequest):
    
    table2.update_item(
      Key={
            'EmailAddress': newrequest[0]
        },
        UpdateExpression = "set verified =:updated",
        ExpressionAttributeValues = {':updated':'deletepending'},
        ReturnValues="UPDATED_NEW"
    )
  
    
def sentMailotp(useremail,message):
    from_addr = '2384102107@qq.com'
    password = 'tliksauaubcddhge'
    to_addr = useremail
 
    smtp_server = 'smtp.qq.com'
 
    msg = MIMEText(message,'plain','utf-8')
    msg['From'] = Header(from_addr)
    msg['To'] = Header(to_addr)
    msg['Subject'] = Header('Your OTP code')
    server=smtplib.SMTP_SSL(smtp_server)
    server.connect(smtp_server,465)
    server.login(from_addr, password)
    server.sendmail(from_addr, to_addr, msg.as_string())
    server.quit()  
def verifiedUser(finduserrequest):
     #if in db  
    isExist = table2.scan(FilterExpression=Attr(userID).eq(finduserrequest[0]) & Attr(veriF).eq('yes'))
    if isExist['Count']!=0: #exist
        return True
       
    elif isExist['Count']==0: #not exist
        return False
    #else exp

def dispatch(intent_request):
    slots = intent_request['currentIntent']['slots']
    useremail=slots['useremail']
    db_password=slots['password']
    cancelIntent=slots['cancelIntent']
    # cancelIntent='yes'
    # useremail='makixian@outlook.com'
    # db_password='2534'
    
    
    if cancelIntent and not useremail and not db_password:
        if cancelIntent=='yes':
            return {
                "dialogAction": {
                    "type": "ElicitSlot",
                    "intentName": intent_request['currentIntent']['name'],
                    "slots": intent_request['currentIntent']['slots'],
                    "slotToElicit": "useremail"
                }
                }
        else:
            return close('Okay. What can I do for you next?')
    
    if useremail and not db_password:
        otp=str(generateOTP())
        message="OTP CODE: "+otp
        finduserrequest=[useremail,otp]
        if verifiedUser(finduserrequest)==True:
             sentMailotp(useremail,message)
             if kms.kmsen(finduserrequest):
                return {
                "dialogAction": {
                    "type": "ElicitSlot",
                    "message": {
                        "contentType": "PlainText",
                        "content": "Please enter the verification code. An OTP code already has sent to your email address."
                    },
                    "intentName": intent_request['currentIntent']['name'],
                    "slots": intent_request['currentIntent']['slots'],
                    "slotToElicit": "password"
                    
                }
                }
             else:
                return close("Unknown Error, please try it again.")
        elif verifiedUser(finduserrequest)==False:
             return close('Hi,but this email address has not been registered.')
    if useremail and db_password:
         finduserrequest=[useremail,db_password]
         if verifiedUser(finduserrequest)==True:
             otp=kms.kmsde(finduserrequest)
             if db_password==otp:
                cancelrequest=[useremail]
                return accountstatus_change(cancelrequest)
             else:
                return close('OTP is Error.')
      
         elif verifiedUser(finduserrequest)==False:
             return close('Hi,but this email address has not been registered.')
    



    

def accountstatus_change(cancelrequest):
    vUser(cancelrequest)
    message='Your email account {} is applying for cancellation and we will reply to you within 3 working days'.format(cancelrequest[0])
    content='Your request was just recieved and we will reply to you within 3 working days.'
    sentMail(cancelrequest,message)
    return close(content)
    
def sentMail(cancelrequest,message):
    from_addr = '2384102107@qq.com'
    password = 'tliksauaubcddhge'
    to_addr = cancelrequest[0]
 
    smtp_server = 'smtp.qq.com'
 
    msg = MIMEText(message,'plain','utf-8')
    msg['From'] = Header(from_addr)
    msg['To'] = Header(to_addr)
    msg['Subject'] = Header('Onlinepurchasedemo: Your Account Status Changed')
    server=smtplib.SMTP_SSL(smtp_server)
    server.connect(smtp_server,465)
    server.login(from_addr, password)
    server.sendmail(from_addr, to_addr, msg.as_string())
    server.quit()  

def close(content):
  response={
    #   'sessionAttributes': session_attributes,
      'dialogAction': {
        "type": 'Close',
        "fulfillmentState": 'Fulfilled',
        'message': {
          'content': content,
          'contentType': "PlainText"
    }
  }
}
  
  return response
  

def lambda_handler(event, context):
    response=dispatch(event)
    return response