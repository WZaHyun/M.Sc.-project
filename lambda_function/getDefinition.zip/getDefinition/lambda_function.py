import json
import csv
import boto3


def sets3():
  s3=boto3.resource('s3')
  
  bucket = s3.Bucket('lookup-bucket-1')
  obj=bucket.Object('MLglossary.csv')
  response = obj.get()
  lines = response['Body'].read().decode('utf-8').splitlines()
  data=[]
  for row in csv.DictReader(lines):
   
   
    data.append(row)
    # here you get a sequence of dicts
    # do whatever you want with each line here
  return(data)#data[0]['definition'] gets the first item's definition /data[0]['terms'] 
    
    

  
def findTerm(term,data):
  
  for i in range(0,len(data)):
    if(term==data[i]['term'].lower()):
      # print(term+"AAA"+data[i]['term'].lower())
       return(data[i]['definition'])
   
  return("Not in glossary.")
  


def close(content):
  response={
      
      'dialogAction': {
        "type": 'Close',
        "fulfillmentState": 'Fulfilled',
        'message': {
          'content': content,
          'contentType': "PlainText"
    }
  }
}
  
  return response


def lambda_handler(event, context):
  data=sets3() #saveDict
  # term='Y'
  term=event['currentIntent']['slots']['term']
  # term=intent_request['inputTranscript']
  term=term.lower()
  # definition='In NLP behaviour is an individual expression of all the filter system we each use to explain and express our world.'
  definition=findTerm(term,data)#callback
  response=close(definition)
  return response
  
  