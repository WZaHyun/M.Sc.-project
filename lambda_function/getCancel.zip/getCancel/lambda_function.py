import json
import boto3
import smtplib
import kms
import math, random
from email.mime.text import MIMEText
from email.header import Header
from boto3.dynamodb.conditions import Key, Attr
_TableName_="UserOrder"
#define parameters
orderID='OrderId'

client = boto3.client('dynamodb')
DB=boto3.resource('dynamodb')
table=DB.Table(_TableName_)

_TableName2_="UserInfo"
#define parameters
userID='EmailAddress'
veriF='verified'

client2 = boto3.client('dynamodb')
DB2=boto3.resource('dynamodb')
table2=DB2.Table(_TableName2_)

otp=''

def generateOTP() : 
  
    # Declare a digits variable   
    # which stores all digits  
    digits = "0123456789"
    OTP = "" 
   # length of password can be chaged 
   # by changing value in range 
    for i in range(4) : 
        OTP += digits[math.floor(random.random() * 10)] 
  
    return OTP 
def vUser(newrequest):
    
    table2.update_item(
      Key={
            'EmailAddress': newrequest[0]
        },
        UpdateExpression = "set passwordbase64 =:updated",
        ExpressionAttributeValues = {':updated':''},
        ReturnValues="UPDATED_NEW"
    )

def sentMailotp(useremail,message):
    from_addr = '2384102107@qq.com'
    password = 'tliksauaubcddhge'
    to_addr = useremail
 
    smtp_server = 'smtp.qq.com'
 
    msg = MIMEText(message,'plain','utf-8')
    msg['From'] = Header(from_addr)
    msg['To'] = Header(to_addr)
    msg['Subject'] = Header('Your OTP code')
    server=smtplib.SMTP_SSL(smtp_server)
    server.connect(smtp_server,465)
    server.login(from_addr, password)
    server.sendmail(from_addr, to_addr, msg.as_string())
    server.quit()  
def verifiedUser(finduserrequest):
     #if in db  
    isExist = table2.scan(FilterExpression=Attr(userID).eq(finduserrequest[0]) & Attr(veriF).eq('yes'))
    if isExist['Count']!=0: #exist
        return True
       
    elif isExist['Count']==0: #not exist
        return False
    #else exp

def dispatch(intent_request):
    slots = intent_request['currentIntent']['slots']
    useremail=slots['useremail']
    db_password=slots['password']
    orderid=slots['orderid']
    # orderid='5025c04a-b38c-4aa8-bfae-f1cca17f000b'
    # useremail='makixian@outlook.com'
    # db_password='5341'
    # orderid='
    
    
    if useremail and not db_password and not orderid:
        otp=str(generateOTP())
        message="OTP CODE: "+otp
        finduserrequest=[useremail,otp]
        if verifiedUser(finduserrequest)==True:
             sentMailotp(useremail,message)
             if kms.kmsen(finduserrequest):
                return {
                "dialogAction": {
                    "type": "ElicitSlot",
                    "message": {
                        "contentType": "PlainText",
                        "content": "Please enter the verification code. An OTP code already has sent to your email address."
                    },
                    "intentName": intent_request['currentIntent']['name'],
                    "slots": intent_request['currentIntent']['slots'],
                    "slotToElicit": "password"
                    
                }
                }
             else:
                return close("Unknown Error, please try it again.")
        elif verifiedUser(finduserrequest)==False:
             return close('Hi,but this email address has not been registered. You should sign up first.')
    if useremail and db_password and not orderid:
         finduserrequest=[useremail,db_password]
         if verifiedUser(finduserrequest)==True:
             otp=kms.kmsde(finduserrequest)
             if db_password==otp:
                return {
                "dialogAction": {
                    "type": "ElicitSlot",
                    "intentName": intent_request['currentIntent']['name'],
                    "slots": intent_request['currentIntent']['slots'],
                    "slotToElicit": "orderid"
                    
                }
                }
                
             else:
                return close('OTP Error.')
      
         elif verifiedUser(finduserrequest)==False:
             return close('Hi,but this email address has not been registered. You should sign up first.')
    if useremail and db_password and orderid:
        finduserrequest=[useremail]
        useremail2=findEmailAddress(orderid)
        if useremail==useremail2: #compare
          cancelrequest=[orderid,useremail]
          vUser(finduserrequest)
          return cancelorder(cancelrequest)
        else:
          return close('Order code error. Please check it again')

def findEmailAddress(orderid):
    orderlist = table.scan(FilterExpression=Attr(orderID).eq(orderid))
    
    if orderlist['Count']==0:
      return close("The code provided is not exist.")
    else:
      useremail=orderlist['Items'][0]['EmailAddress']
      return useremail
    

    

def cancelorder(cancelrequest):
    updateOrder(cancelrequest)
    message='Your order {} is applying for cancellation and we will reply to you within 3 working days'.format(cancelrequest[0])
    content='Your request was just recieved and we will reply to you within 3 working days.'
    sentMail(cancelrequest,message)
    return close(content)
    
def updateOrder(pendingrequest):
    table.update_item(
      Key={
            'OrderId': pendingrequest[0]
        },
        UpdateExpression = "set OrderState =:updated",
        ExpressionAttributeValues = {':updated':'Pending'},
        ReturnValues="UPDATED_NEW"
    )
    
def sentMail(cancelrequest,message):
    from_addr = '2384102107@qq.com'
    password = 'tliksauaubcddhge'
    to_addr = cancelrequest[1]
 
    smtp_server = 'smtp.qq.com'
 
    msg = MIMEText(message,'plain','utf-8')
    msg['From'] = Header(from_addr)
    msg['To'] = Header(to_addr)
    msg['Subject'] = Header('Your Order Status Changed')
    server=smtplib.SMTP_SSL(smtp_server)
    server.connect(smtp_server,465)
    server.login(from_addr, password)
    server.sendmail(from_addr, to_addr, msg.as_string())
    server.quit()  

def close(content):
  response={
    #   'sessionAttributes': session_attributes,
      'dialogAction': {
        "type": 'Close',
        "fulfillmentState": 'Fulfilled',
        'message': {
          'content': content,
          'contentType': "PlainText"
    }
  }
}
  
  return response
  

def lambda_handler(event, context):
    response=dispatch(event)
    return response