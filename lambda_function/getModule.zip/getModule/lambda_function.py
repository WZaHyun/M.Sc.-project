import json
import csv
import boto3
import uuid
import smtplib
import kms
import math, random
from email.mime.text import MIMEText
from email.header import Header

from boto3.dynamodb.conditions import Key, Attr
_TableName_="ModuleInfo"
#define parameters
moduleID='M-id'
moduleName='M-name'
moduleType='M-type'
Primary_Key = '1'
client = boto3.client('dynamodb')
DB=boto3.resource('dynamodb')
table=DB.Table(_TableName_)

_TableName2_="UserInfo"
#define parameters
userID='EmailAddress'
veriF='verified'
client2 = boto3.client('dynamodb')
DB2=boto3.resource('dynamodb')
table2=DB2.Table(_TableName2_)

_TableName3_="UserOrder"
#define parameters
orderID='OrderId'

client3 = boto3.client('dynamodb')
DB3=boto3.resource('dynamodb')
table3=DB3.Table(_TableName3_)

otp=''


def generateOTP() : 
  
    # Declare a digits variable   
    # which stores all digits  
    digits = "0123456789"
    OTP = "" 
   # length of password can be chaged 
   # by changing value in range 
    for i in range(4) : 
        OTP += digits[math.floor(random.random() * 10)] 
  
    return OTP 
  
def vUser(newrequest):
    
    table2.update_item(
      Key={
            'EmailAddress': newrequest[0]
        },
        UpdateExpression = "set passwordbase64 =:updated",
        ExpressionAttributeValues = {':updated':''},
        ReturnValues="UPDATED_NEW"
    )

def sentMailotp(useremail,message):
    from_addr = '2384102107@qq.com'
    password = 'tliksauaubcddhge'
    to_addr = useremail
 
    smtp_server = 'smtp.qq.com'
 
    msg = MIMEText(message,'plain','utf-8')
    msg['From'] = Header(from_addr)
    msg['To'] = Header(to_addr)
    msg['Subject'] = Header('Your OTP code')
    server=smtplib.SMTP_SSL(smtp_server)
    server.connect(smtp_server,465)
    server.login(from_addr, password)
    server.sendmail(from_addr, to_addr, msg.as_string())
    server.quit()  

    
def dispatch(intent_request,requestid):
    slots = intent_request['currentIntent']['slots']
    useremail=slots['useremail']
    db_password=slots['password']
    modulename=slots['modulename']
    moduletype=slots['moduletype']
    # modulename='deep learning'
    # moduletype='advanced'
    # db_password='3001'
    # # useremail=None
    # useremail='0307zixian@gmail.com'
    
    # modulename='machine learning'
    # moduletype='primer'
   
    
    if useremail and not db_password and not modulename and not moduletype:
        otp=str(generateOTP())
        message="OTP CODE: "+otp
        finduserrequest=[useremail,otp]
        
        if verifiedUser(finduserrequest)==True:
             sentMailotp(useremail,message)
            #  print(otp)
             if kms.kmsen(finduserrequest):
                return {
                "dialogAction": {
                    "type": "ElicitSlot",
                    "message": {
                        "contentType": "PlainText",
                        "content": "Please enter the verification code. An OTP code already has sent to your email address."
                    },
                    "intentName": intent_request['currentIntent']['name'],
                    "slots": intent_request['currentIntent']['slots'],
                    "slotToElicit": "password"
                    
                }
                }
             else:
                return close("Unknown Error, please try it again.")
        elif verifiedUser(finduserrequest)==False:
             return close('Hi,but this email address has not been registered. You should sign up first.')
             
    
        
    if useremail and db_password and not modulename and not moduletype:
         finduserrequest=[useremail,db_password]
         if verifiedUser(finduserrequest)==True:
             otp=kms.kmsde(finduserrequest)
             if db_password==otp:
               
                return {
                "dialogAction": {
                    "type": "ElicitSlot",
                    "message": {
                        "contentType": "PlainText",
                        "content": "Thank you, Now you could buy courses online."
                    },
                    "intentName": intent_request['currentIntent']['name'],
                    "slots": intent_request['currentIntent']['slots'],
                    "slotToElicit": "modulename"
                    
                }
                }
                
             else:
                return close('OTP Error.')
      
         elif verifiedUser(finduserrequest)==False:
             return close('Hi,but this email address has not been registered. You should sign up first.')
    if useremail and not db_password and modulename and moduletype:
        otp=str(generateOTP())
        message="OTP CODE: "+otp
        finduserrequest=[useremail,otp]
        if verifiedUser(finduserrequest)==True:
             sentMailotp(useremail,message)
             if kms.kmsen(finduserrequest):
                return {
                "dialogAction": {
                    "type": "ElicitSlot",
                    "message": {
                        "contentType": "PlainText",
                        "content": "Please enter the verification code. An OTP code already has sent to your email address."
                    },
                    "intentName": intent_request['currentIntent']['name'],
                    "slots": intent_request['currentIntent']['slots'],
                    "slotToElicit": "password"
                    
                }
                }
             else:
                return close("Unknown Error, please try it again.")
        elif verifiedUser(finduserrequest)==False:
             return close('Hi,but this email address has not been registered. You should sign up first.')
             
    
    if modulename and not moduletype:
         return {
                "dialogAction": {
                    "type": "ElicitSlot",
                    
                    "intentName": intent_request['currentIntent']['name'],
                    "slots": intent_request['currentIntent']['slots'],
                    "slotToElicit": "moduletype"
                    
                }
                }
                
                
                 
    if useremail and db_password and modulename and moduletype :
         finduserrequest=[useremail,db_password]
         if verifiedUser(finduserrequest)==True:
             otp=kms.kmsde(finduserrequest)
             if db_password==otp:
                vUser(finduserrequest)
                modulebookrequest=[modulename,moduletype,useremail,requestid]
                return findModule(modulebookrequest)
             else:
                
                return close('OTP Error.')
             
         elif verifiedUser(finduserrequest)==False:
             return close('Hi,but this email address has not been registered. You should sign up first.')
         
def verifiedUser(finduserrequest):
     #if in db  
    isExist = table2.scan(FilterExpression=Attr(userID).eq(finduserrequest[0]) & Attr(veriF).eq('yes'))
    if isExist['Count']!=0: #exist
        return True
       
    elif isExist['Count']==0: #not exist
        return False
    #else exp


def findModule(modulebookrequest):#in ... db?
    #if in db  
    response = table.scan(FilterExpression=Attr(moduleName).eq(modulebookrequest[0]) & Attr(moduleType).eq(modulebookrequest[1]))
    # print(response)
    if response['Count'] != 0:
        # print("111111")
        return bookModule(response,modulebookrequest)
    else:
        content="Sorry,but this module does not exist."
        return close(content)
    #else exp


    


def bookModule(response,modulebookrequest):#response
    response2=response['Items']
  
    
    table3.put_item(
      Item={
            'OrderId': modulebookrequest[3],
            'EmailAddress': modulebookrequest[2] ,
            'M-id': response2[0]['M-id'],
            'OrderState':'Booked'
           
        }
    )
    
    message='Your order has already placed. Module Name:'+response2[0]['M-name']+\
    ' Module Type:'+response2[0]['M-type']+' Module Price:'+str(response2[0]['M-price'])+'£'\
    +'\n Your Order Code:{}'.format(modulebookrequest[3])+\
    '\n This order code is very important, please keep it properly. If you want to cancel'+\
    ' the order, you need to provide the code. We have sent the same content to your email address.'
    sentMail(modulebookrequest[2],message)
    return close(message)  #connect to the bookedlist db,and randomly create a new learning code for users.
   
def sentMail(useremail,message):
    from_addr = '2384102107@qq.com'
    password = 'tliksauaubcddhge'
    to_addr = useremail
 
    smtp_server = 'smtp.qq.com'
 
    msg = MIMEText(message,'plain','utf-8')
    msg['From'] = Header(from_addr)
    msg['To'] = Header(to_addr)
    msg['Subject'] = Header('Purchase Succeed')
    server=smtplib.SMTP_SSL(smtp_server)
    server.connect(smtp_server,465)
    server.login(from_addr, password)
    server.sendmail(from_addr, to_addr, msg.as_string())
    server.quit()  
 #--------------------findModule response------------------------   

def confirm_intent(session_attributes, intent_name, slots, message):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'ConfirmIntent',
            'intentName': intent_name,
            'slots': slots,
            'message': {
                'contentType': 'PlainText',
                'content': message
            }
        }
    }




def close(content):
  response={
    #   'sessionAttributes': session_attributes,
      'dialogAction': {
        "type": 'Close',
        "fulfillmentState": 'Fulfilled',
        'message': {
          'content': content,
          'contentType': "PlainText"
    }
  }
}
  
  return response
  


  


def lambda_handler(event, context):
    response=dispatch(event,str(context.aws_request_id))
    
   
    # TODO implement
    return response
    
